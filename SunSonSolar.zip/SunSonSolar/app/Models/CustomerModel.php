
<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table = 'customers';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'fname',
        'lname',
        'mname',
        'birthdate',
        'gender',
        'email',
        'phone',
        'address',
        'username',
        'password'
    ];
}
